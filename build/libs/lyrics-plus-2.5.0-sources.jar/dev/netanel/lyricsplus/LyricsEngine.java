package dev.netanel.lyricsplus;

import dev.netanel.lyricsplus.backend.LinuxMusicManager;
import dev.netanel.lyricsplus.backend.LyricsFetcher;
import dev.netanel.lyricsplus.backend.LyricsLine;
import dev.netanel.lyricsplus.backend.MusicManager;
import dev.netanel.lyricsplus.backend.WindowsMusicManager;
import dev.netanel.lyricsplus.config.LyricsConfig;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Tracks the current song, loads lyrics off-thread, and answers "what is on screen right now". */
public final class LyricsEngine {

    public enum Status { NO_PLAYER, AD, LOADING, READY, NOT_FOUND }

    /** Immutable view of the current playback moment, built once per frame. */
    public record Snapshot(
            String title, String artist, long positionMs, long durationMs, boolean playing,
            Status status, List<LyricsLine> lines, int index,
            long lineStartMs, long lineEndMs, long msSinceTrackChange, boolean demo, boolean estimated) {

        public boolean hasLine() {
            return lines != null && index >= 0 && index < lines.size();
        }

        public String line(int offset) {
            int i = index + offset;
            if (lines == null || i < 0 || i >= lines.size()) {
                return "";
            }
            return lines.get(i).getText();
        }

        /** Before the first lyric line, or on an empty (instrumental) line. */
        public boolean instrumental() {
            if (status != Status.READY || lines == null || lines.isEmpty()) {
                return false;
            }
            return index < 0 || line(0).isBlank();
        }
    }

    private static final List<LyricsLine> DEMO_LINES = List.of(
            new LyricsLine(0, ""),
            new LyricsLine(4000, "Welcome to Lyrics Plus"),
            new LyricsLine(7000, "Press ; or type /lyrics"),
            new LyricsLine(10000, "Pick a color and a style"),
            new LyricsLine(13000, "Let the words float in the world"),
            new LyricsLine(16500, "Or sing along karaoke style"),
            new LyricsLine(20000, ""),
            new LyricsLine(23000, "The music never stops")
    );
    private static final long DEMO_LENGTH = 27000;
    private static final long DISPLAY_LEAD_MS = 150;

    private final ExecutorService fetchThread = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "LyricsPlus-Fetch");
        t.setDaemon(true);
        return t;
    });
    private final LyricsFetcher fetcher = new LyricsFetcher();
    private final Map<String, LyricsFetcher.Result> cache = new HashMap<>();
    private final boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");

    private MusicManager music;
    private long nextConnectAttempt;

    private volatile String trackKey = "";
    private volatile String title = "";
    private volatile String artist = "";
    private volatile List<LyricsLine> lines;
    private volatile boolean estimated;
    private volatile Status status = Status.NO_PLAYER;
    private volatile long trackChangedAt = System.currentTimeMillis();
    private volatile int generation;

    private volatile boolean adPlaying;
    private final Object stateLock = new Object();
    private long blankSince = -1;
    private volatile long retryAt = -1;
    private boolean demo;
    private long demoStart;

    public void setDemo(boolean on) {
        if (on == demo) {
            return;
        }
        demo = on;
        demoStart = System.currentTimeMillis();
        trackChangedAt = demoStart;
        if (!on) {
            trackKey = ""; // force a reload of the real song
        }
    }

    /** "artist - title" of the current song, or "" (used for per-song timing). */
    public String trackKey() {
        return demo ? "" : trackKey;
    }

    public boolean isDemo() {
        return demo;
    }

    /** Called every client tick. Cheap: reads cached values from the media thread. */
    public void tick() {
        if (demo) {
            long now = System.currentTimeMillis();
            if (now - demoStart >= DEMO_LENGTH) {
                demoStart = now;
                trackChangedAt = now;
            }
            return;
        }
        ensurePlayer();
        if (music == null) {
            status = Status.NO_PLAYER;
            return;
        }

        String a;
        String t;
        long durSec;
        try {
            a = music.getArtist();
            t = music.getTitle();
            durSec = music.getDuration();
        } catch (Exception e) {
            dropLinuxPlayer();
            status = Status.NO_PLAYER;
            trackKey = "";
            return;
        }
        if (a == null || t == null || t.isBlank()) {
            // Nothing playing for a moment (players blink empty at track change), then clear.
            long now = System.currentTimeMillis();
            if (blankSince < 0) blankSince = now;
            if (now - blankSince > 1000 && !trackKey.isEmpty()) {
                synchronized (stateLock) {
                    trackKey = "";
                    status = Status.NO_PLAYER;
                    lines = null;
                    adPlaying = false;
                    generation++;
                }
            }
            return;
        }
        blankSince = -1;
        // Ads: hide everything until music comes back. The song before the ad keeps its key,
        // so if it simply resumes we don't replay the title card.
        adPlaying = isAd(a, t, durSec);
        if (adPlaying) {
            return;
        }

        String key = a + " - " + t;
        if (!key.equals(trackKey)) {
            onTrackChanged(key, a, t);
        } else if (retryAt > 0 && System.currentTimeMillis() >= retryAt) {
            retryAt = -1; // last lookup failed because of the network: try again
            startFetch(key, a, t);
        }
    }

    static boolean isAd(String artist, String title, long durationSec) {
        String t = title.trim().toLowerCase(java.util.Locale.ROOT);
        String a = artist.trim().toLowerCase(java.util.Locale.ROOT);
        if (t.equals("advertisement") || t.equals("spotify") || t.equals("spotify free")
                || t.startsWith("advertisement") || t.equals("ad") || t.startsWith("ad ·") || t.startsWith("ad:")) {
            return true;
        }
        if (a.equals("spotify") || a.equals("advertisement")) {
            return true;
        }
        // Spotify ads come with no artist and are short. A long song with no artist tag
        // (e.g. a local file) is not an ad.
        return a.isEmpty() && durationSec > 0 && durationSec <= 65;
    }

    private void ensurePlayer() {
        if (music != null || System.currentTimeMillis() < nextConnectAttempt) {
            return;
        }
        nextConnectAttempt = System.currentTimeMillis() + 5000;
        try {
            music = windows ? new WindowsMusicManager() : new LinuxMusicManager();
        } catch (Throwable e) {
            music = null;
        }
    }

    /** Linux: Spotify probably closed. Drop the D-Bus player and reconnect later. Windows keeps its poller. */
    private void dropLinuxPlayer() {
        if (windows || music == null) {
            return;
        }
        MusicManager m = music;
        music = null;
        try {
            m.close();
        } catch (Exception ignored) {
        }
    }

    private void onTrackChanged(String key, String a, String t) {
        retryAt = -1;
        LyricsFetcher.Result cached;
        synchronized (cache) {
            cached = cache.get(key);
        }
        synchronized (stateLock) {
            trackKey = key;
            artist = a;
            title = t;
            trackChangedAt = System.currentTimeMillis();
            generation++;
            if (cached != null) {
                lines = cached.lines();
                estimated = cached.estimated();
                status = cached.lines().isEmpty() ? Status.NOT_FOUND : Status.READY;
            }
        }
        dev.netanel.lyricsplus.backend.AlbumArt.request(a, t);
        if (cached == null) {
            startFetch(key, a, t);
        }
    }

    private void startFetch(String key, String a, String t) {
        int gen;
        synchronized (stateLock) {
            gen = generation;
            lines = null;
            estimated = false;
            status = Status.LOADING;
        }
        MusicManager player = music;
        fetchThread.submit(() -> {
            try {
                // Right after a track change the player may still report the previous length.
                Thread.sleep(700);
            } catch (InterruptedException e) {
                return;
            }
            if (gen != generation || player == null) {
                return;
            }
            String album = safe(player::getAlbum);
            long durationSec;
            try {
                durationSec = player.getDuration();
            } catch (Exception e) {
                durationSec = 0;
            }
            LyricsFetcher.Result result = fetcher.fetch(a, t, album, durationSec, () -> gen != generation);
            if (gen != generation) {
                return; // song changed mid-fetch: don't cache a possibly cut-short result
            }
            if (!result.failed()) {
                synchronized (cache) {
                    cache.put(key, result);
                }
            }
            synchronized (stateLock) {
                if (gen != generation) {
                    return; // a different song is playing now
                }
                lines = result.lines();
                estimated = result.estimated();
                status = result.lines().isEmpty() ? Status.NOT_FOUND : Status.READY;
                if (result.failed()) {
                    retryAt = System.currentTimeMillis() + 30_000;
                }
            }
        });
    }

    public Snapshot snapshot() {
        LyricsConfig cfg = LyricsConfig.get();
        long now = System.currentTimeMillis();

        if (demo) {
            long pos = now - demoStart;
            return build("Lyrics Plus Demo", "Netanel", pos, DEMO_LENGTH, true,
                    Status.READY, DEMO_LINES, now - trackChangedAt, true, false);
        }
        MusicManager m = music;
        if (m == null) {
            return build("", "", 0, 0, false, Status.NO_PLAYER, null, now - trackChangedAt, false, false);
        }
        if (adPlaying) {
            return build("", "", 0, 0, false, Status.AD, null, now - trackChangedAt, false, false);
        }
        long rawPos;
        long durMs;
        boolean playing;
        try {
            rawPos = m.getPosition();
            durMs = m.getDuration() * 1000L;
            playing = m.isPlaying();
        } catch (Exception e) {
            // Linux: the player vanished between ticks. Never let that crash the HUD.
            return build("", "", 0, 0, false, Status.NO_PLAYER, null, now - trackChangedAt, false, false);
        }
        // Show lyrics slightly ahead so entry animations finish on the beat, then apply delays.
        long pos = rawPos + DISPLAY_LEAD_MS - cfg.delayMs - cfg.songDelay(trackKey);
        return build(title, artist, pos, durMs, playing, status, lines,
                now - trackChangedAt, false, estimated);
    }

    private static Snapshot build(String title, String artist, long pos, long dur, boolean playing,
                                  Status status, List<LyricsLine> lines, long sinceChange, boolean demo, boolean estimated) {
        int index = -1;
        long start = 0;
        long end = 0;
        if (lines != null && !lines.isEmpty()) {
            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).getTimeStamp() > pos) {
                    break;
                }
                index = i;
            }
            if (index >= 0) {
                start = lines.get(index).getTimeStamp();
                end = index + 1 < lines.size()
                        ? lines.get(index + 1).getTimeStamp()
                        : start + 6000;
            } else {
                end = lines.getFirst().getTimeStamp();
            }
        }
        return new Snapshot(title, artist, Math.max(0, pos), dur, playing, status, lines, index,
                start, end, sinceChange, demo, estimated);
    }

    private static String safe(java.util.function.Supplier<String> s) {
        try {
            String v = s.get();
            return v == null ? "" : v;
        } catch (Exception e) {
            return "";
        }
    }
}
